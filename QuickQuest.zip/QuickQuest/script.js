// Example of a basic JavaScript interaction
document.addEventListener('DOMContentLoaded', function() {
    alert('Welcome to Quick Quest!');
});